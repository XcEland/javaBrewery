public class ProductDecision{
    @JsonProperty("FIN") 
    public FIN getFIN() { 
		 return this.fIN; } 
    public void setFIN(FIN fIN) { 
		 this.fIN = fIN; } 
    FIN fIN;
    @JsonProperty("@metadata") 
    public Metadata get@metadata() { 
		 return this.@metadata; } 
    public void set@metadata(Metadata @metadata) { 
		 this.@metadata = @metadata; } 
    Metadata @metadata;
    @JsonProperty("DecisionCod") 
    public String getDecisionCod() { 
		 return this.decisionCod; } 
    public void setDecisionCod(String decisionCod) { 
		 this.decisionCod = decisionCod; } 
    String decisionCod;
    @JsonProperty("DeclineCod1") 
    public String getDeclineCod1() { 
		 return this.declineCod1; } 
    public void setDeclineCod1(String declineCod1) { 
		 this.declineCod1 = declineCod1; } 
    String declineCod1;
    @JsonProperty("DeclineCod2") 
    public String getDeclineCod2() { 
		 return this.declineCod2; } 
    public void setDeclineCod2(String declineCod2) { 
		 this.declineCod2 = declineCod2; } 
    String declineCod2;
    @JsonProperty("DeclineCod3") 
    public String getDeclineCod3() { 
		 return this.declineCod3; } 
    public void setDeclineCod3(String declineCod3) { 
		 this.declineCod3 = declineCod3; } 
    String declineCod3;
    @JsonProperty("DeclineCod4") 
    public String getDeclineCod4() { 
		 return this.declineCod4; } 
    public void setDeclineCod4(String declineCod4) { 
		 this.declineCod4 = declineCod4; } 
    String declineCod4;
    @JsonProperty("DeclineCod5") 
    public String getDeclineCod5() { 
		 return this.declineCod5; } 
    public void setDeclineCod5(String declineCod5) { 
		 this.declineCod5 = declineCod5; } 
    String declineCod5;
    @JsonProperty("DeclineCod6") 
    public String getDeclineCod6() { 
		 return this.declineCod6; } 
    public void setDeclineCod6(String declineCod6) { 
		 this.declineCod6 = declineCod6; } 
    String declineCod6;
    @JsonProperty("DeclineCod7") 
    public String getDeclineCod7() { 
		 return this.declineCod7; } 
    public void setDeclineCod7(String declineCod7) { 
		 this.declineCod7 = declineCod7; } 
    String declineCod7;
    @JsonProperty("DeclineCod8") 
    public String getDeclineCod8() { 
		 return this.declineCod8; } 
    public void setDeclineCod8(String declineCod8) { 
		 this.declineCod8 = declineCod8; } 
    String declineCod8;
    @JsonProperty("DeclineCod9") 
    public String getDeclineCod9() { 
		 return this.declineCod9; } 
    public void setDeclineCod9(String declineCod9) { 
		 this.declineCod9 = declineCod9; } 
    String declineCod9;
    @JsonProperty("DeclineCod10") 
    public String getDeclineCod10() { 
		 return this.declineCod10; } 
    public void setDeclineCod10(String declineCod10) { 
		 this.declineCod10 = declineCod10; } 
    String declineCod10;
    @JsonProperty("RollDecision") 
    public String getRollDecision() { 
		 return this.rollDecision; } 
    public void setRollDecision(String rollDecision) { 
		 this.rollDecision = rollDecision; } 
    String rollDecision;
}
