public class ProductCaf{
    @JsonProperty("loanTerm") 
    public double getLoanTerm() { 
		 return this.loanTerm; } 
    public void setLoanTerm(double loanTerm) { 
		 this.loanTerm = loanTerm; } 
    double loanTerm;
    @JsonProperty("instalNo") 
    public int getInstalNo() { 
		 return this.instalNo; } 
    public void setInstalNo(int instalNo) { 
		 this.instalNo = instalNo; } 
    int instalNo;
    @JsonProperty("extr1Amount") 
    public double getExtr1Amount() { 
		 return this.extr1Amount; } 
    public void setExtr1Amount(double extr1Amount) { 
		 this.extr1Amount = extr1Amount; } 
    double extr1Amount;
    @JsonProperty("extr2Amount") 
    public double getExtr2Amount() { 
		 return this.extr2Amount; } 
    public void setExtr2Amount(double extr2Amount) { 
		 this.extr2Amount = extr2Amount; } 
    double extr2Amount;
    @JsonProperty("extr1Desc") 
    public String getExtr1Desc() { 
		 return this.extr1Desc; } 
    public void setExtr1Desc(String extr1Desc) { 
		 this.extr1Desc = extr1Desc; } 
    String extr1Desc;
    @JsonProperty("extr2Desc") 
    public String getExtr2Desc() { 
		 return this.extr2Desc; } 
    public void setExtr2Desc(String extr2Desc) { 
		 this.extr2Desc = extr2Desc; } 
    String extr2Desc;
    @JsonProperty("goodsDesc") 
    public String getGoodsDesc() { 
		 return this.goodsDesc; } 
    public void setGoodsDesc(String goodsDesc) { 
		 this.goodsDesc = goodsDesc; } 
    String goodsDesc;
    @JsonProperty("goodsAge") 
    public int getGoodsAge() { 
		 return this.goodsAge; } 
    public void setGoodsAge(int goodsAge) { 
		 this.goodsAge = goodsAge; } 
    int goodsAge;
    @JsonProperty("resAmount") 
    public double getResAmount() { 
		 return this.resAmount; } 
    public void setResAmount(double resAmount) { 
		 this.resAmount = resAmount; } 
    double resAmount;
    @JsonProperty("channelIndicator") 
    public String getChannelIndicator() { 
		 return this.channelIndicator; } 
    public void setChannelIndicator(String channelIndicator) { 
		 this.channelIndicator = channelIndicator; } 
    String channelIndicator;
    @JsonProperty("goodsTypeCode") 
    public String getGoodsTypeCode() { 
		 return this.goodsTypeCode; } 
    public void setGoodsTypeCode(String goodsTypeCode) { 
		 this.goodsTypeCode = goodsTypeCode; } 
    String goodsTypeCode;
    @JsonProperty("digstPriceAmnt") 
    public double getDigstPriceAmnt() { 
		 return this.digstPriceAmnt; } 
    public void setDigstPriceAmnt(double digstPriceAmnt) { 
		 this.digstPriceAmnt = digstPriceAmnt; } 
    double digstPriceAmnt;
    @JsonProperty("newUsed") 
    public String getNewUsed() { 
		 return this.newUsed; } 
    public void setNewUsed(String newUsed) { 
		 this.newUsed = newUsed; } 
    String newUsed;
    @JsonProperty("depAmnt") 
    public double getDepAmnt() { 
		 return this.depAmnt; } 
    public void setDepAmnt(double depAmnt) { 
		 this.depAmnt = depAmnt; } 
    double depAmnt;
    @JsonProperty("cashValueAmnt") 
    public double getCashValueAmnt() { 
		 return this.cashValueAmnt; } 
    public void setCashValueAmnt(double cashValueAmnt) { 
		 this.cashValueAmnt = cashValueAmnt; } 
    double cashValueAmnt;
    @JsonProperty("equityOfGoods") 
    public double getEquityOfGoods() { 
		 return this.equityOfGoods; } 
    public void setEquityOfGoods(double equityOfGoods) { 
		 this.equityOfGoods = equityOfGoods; } 
    double equityOfGoods;
    @JsonProperty("interestP") 
    public double getInterestP() { 
		 return this.interestP; } 
    public void setInterestP(double interestP) { 
		 this.interestP = interestP; } 
    double interestP;
    @JsonProperty("itemAge") 
    public int getItemAge() { 
		 return this.itemAge; } 
    public void setItemAge(int itemAge) { 
		 this.itemAge = itemAge; } 
    int itemAge;
    @JsonProperty("totalExpsreAmnt") 
    public double getTotalExpsreAmnt() { 
		 return this.totalExpsreAmnt; } 
    public void setTotalExpsreAmnt(double totalExpsreAmnt) { 
		 this.totalExpsreAmnt = totalExpsreAmnt; } 
    double totalExpsreAmnt;
    @JsonProperty("dealerNo") 
    public double getDealerNo() { 
		 return this.dealerNo; } 
    public void setDealerNo(double dealerNo) { 
		 this.dealerNo = dealerNo; } 
    double dealerNo;
    @JsonProperty("installSettlement") 
    public double getInstallSettlement() { 
		 return this.installSettlement; } 
    public void setInstallSettlement(double installSettlement) { 
		 this.installSettlement = installSettlement; } 
    double installSettlement;
    @JsonProperty("cashAssetPrice") 
    public double getCashAssetPrice() { 
		 return this.cashAssetPrice; } 
    public void setCashAssetPrice(double cashAssetPrice) { 
		 this.cashAssetPrice = cashAssetPrice; } 
    double cashAssetPrice;
    @JsonProperty("residualP") 
    public int getResidualP() { 
		 return this.residualP; } 
    public void setResidualP(int residualP) { 
		 this.residualP = residualP; } 
    int residualP;
    @JsonProperty("deliveryInstFuel") 
    public double getDeliveryInstFuel() { 
		 return this.deliveryInstFuel; } 
    public void setDeliveryInstFuel(double deliveryInstFuel) { 
		 this.deliveryInstFuel = deliveryInstFuel; } 
    double deliveryInstFuel;
    @JsonProperty("mwiWarPrem") 
    public double getMwiWarPrem() { 
		 return this.mwiWarPrem; } 
    public void setMwiWarPrem(double mwiWarPrem) { 
		 this.mwiWarPrem = mwiWarPrem; } 
    double mwiWarPrem;
    @JsonProperty("paintechPrem") 
    public double getPaintechPrem() { 
		 return this.paintechPrem; } 
    public void setPaintechPrem(double paintechPrem) { 
		 this.paintechPrem = paintechPrem; } 
    double paintechPrem;
    @JsonProperty("mmcode") 
    public double getMmcode() { 
		 return this.mmcode; } 
    public void setMmcode(double mmcode) { 
		 this.mmcode = mmcode; } 
    double mmcode;
    @JsonProperty("vehDigestExtr") 
    public double getVehDigestExtr() { 
		 return this.vehDigestExtr; } 
    public void setVehDigestExtr(double vehDigestExtr) { 
		 this.vehDigestExtr = vehDigestExtr; } 
    double vehDigestExtr;
    @JsonProperty("setExpsreAmnt") 
    public double getSetExpsreAmnt() { 
		 return this.setExpsreAmnt; } 
    public void setSetExpsreAmnt(double setExpsreAmnt) { 
		 this.setExpsreAmnt = setExpsreAmnt; } 
    double setExpsreAmnt;
    @JsonProperty("balloonPercent") 
    public String getBalloonPercent() { 
		 return this.balloonPercent; } 
    public void setBalloonPercent(String balloonPercent) { 
		 this.balloonPercent = balloonPercent; } 
    String balloonPercent;
    @JsonProperty("cashPriceAmnt") 
    public double getCashPriceAmnt() { 
		 return this.cashPriceAmnt; } 
    public void setCashPriceAmnt(double cashPriceAmnt) { 
		 this.cashPriceAmnt = cashPriceAmnt; } 
    double cashPriceAmnt;
    @JsonProperty("@metadata") 
    public Metadata get@metadata() { 
		 return this.@metadata; } 
    public void set@metadata(Metadata @metadata) { 
		 this.@metadata = @metadata; } 
    Metadata @metadata;
}
