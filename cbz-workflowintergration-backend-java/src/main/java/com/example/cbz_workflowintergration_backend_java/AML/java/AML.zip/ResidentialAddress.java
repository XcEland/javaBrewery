public class ResidentialAddress{
    public String postalCode;
    public String suburb;
    public String province;
    public String streetName;
    public String type;
    public String city;
    public String country;
    public Metadata @metadata;
}
