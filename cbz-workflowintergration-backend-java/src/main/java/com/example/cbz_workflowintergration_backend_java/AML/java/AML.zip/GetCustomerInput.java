public class GetCustomerInput{
    public String bpid;
    public String accountNumber;
    public String srcSystemID;
    public ServiceHeaderDetails serviceHeaderDetails;
    public Metadata @metadata;
}
