public class LoginIdent{
    public String loginAuthority;
    public String loginName;
    public Metadata @metadata;
}
