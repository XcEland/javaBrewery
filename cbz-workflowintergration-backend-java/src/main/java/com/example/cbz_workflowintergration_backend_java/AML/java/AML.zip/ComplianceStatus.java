public class ComplianceStatus{
    public String complianceStatusCode;
    public String description;
    public Date effectiveDate;
    public StatusReason statusReason;
    public VerifiedBy verifiedBy;
    public Metadata @metadata;
}
