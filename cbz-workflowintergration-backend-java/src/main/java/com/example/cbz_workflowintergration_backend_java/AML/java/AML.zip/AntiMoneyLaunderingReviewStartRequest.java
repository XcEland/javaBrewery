public class AntiMoneyLaunderingReviewStartRequest{
    public ProcessContext processContext;
    public AmlReviewDetails amlReviewDetails;
    public IdentityDetails identityDetails;
    public ResidentialDetails residentialDetails;
    public EmploymentDetails employmentDetails;
    public SourceOfFunds sourceOfFunds;
    public UploadedDocument uploadedDocument;
    public AccountDetails accountDetails;
    public PipDetails pipDetails;
    public Metadata @metadata;
}
