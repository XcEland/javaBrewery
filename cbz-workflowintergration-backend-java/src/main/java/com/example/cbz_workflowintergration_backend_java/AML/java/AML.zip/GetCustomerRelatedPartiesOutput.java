public class GetCustomerRelatedPartiesOutput{
    @JsonProperty("CustomerResponse_Type") 
    public CustomerResponseType customerResponse_Type;
    public Metadata @metadata;
}
