public class CustomerResponseType{
    public RelatedPartiesSummary relatedPartiesSummary;
    public SoleProprietor soleProprietor;
    public Entity entity;
    public ContactDetails contactDetails;
    public Customer customer;
    public Header header;
    public Metadata @metadata;
}
