public class ResidentialDetails{
    public String countryOfResidence;
    public String buildingName;
    public String suburb;
    public String postalCode;
    public String unitFloorRoomNumber;
    public String streetNameAndNumber;
    public String cityTown;
    public String province;
    public String addressLine1;
    public String addressLine2;
    public String addressLine3;
    public String addressLine4;
    public String addressLine5;
    public String addressLine6;
    public Metadata @metadata;
}
