public class NoteType{
    public String code;
    public String description;
    public Metadata @metadata;
}
