public class GetDataResponse{
    @JsonProperty("GetDataResult") 
    public GetDataResult getDataResult;
    public Metadata @metadata;
}
