public class PipDetails{
    public boolean pipInd;
    public boolean pipRelationshipInd;
    public String pipRelationshipType;
    public String pipRelationshipDesc;
    public String pipRelationshipName;
    public String pipRelationshipSurname;
    public Metadata @metadata;
}
