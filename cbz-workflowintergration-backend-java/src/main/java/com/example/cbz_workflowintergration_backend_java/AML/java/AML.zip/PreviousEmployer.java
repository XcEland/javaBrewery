public class PreviousEmployer{
    public String employerName;
    public int yearsAtEmployer;
    public Metadata @metadata;
}
