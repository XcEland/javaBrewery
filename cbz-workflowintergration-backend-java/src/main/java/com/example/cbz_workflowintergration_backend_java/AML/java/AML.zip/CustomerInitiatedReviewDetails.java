public class CustomerInitiatedReviewDetails{
    public String reasonCode;
    public Metadata @metadata;
}
