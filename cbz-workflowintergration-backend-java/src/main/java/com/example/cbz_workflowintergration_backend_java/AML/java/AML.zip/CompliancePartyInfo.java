public class CompliancePartyInfo{
    public boolean relatedPartyIndicator;
    public String fullName;
    public Metadata @metadata;
}
