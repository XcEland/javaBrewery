public class IdentityDetails{
    public ContactDetails contactDetails;
    public CustomerDetails customerDetails;
    public AmendmentReason amendmentReason;
    public Metadata @metadata;
}
