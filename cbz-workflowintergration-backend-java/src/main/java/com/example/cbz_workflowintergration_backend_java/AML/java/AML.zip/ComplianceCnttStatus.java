public class ComplianceCnttStatus{
    public String complianceCnttStatusCode;
    public String description;
    public String validToDate;
    public StatusReason statusReason;
    public VerifiedBy verifiedBy;
    public Metadata @metadata;
    public boolean exemptionIndicator;
}
