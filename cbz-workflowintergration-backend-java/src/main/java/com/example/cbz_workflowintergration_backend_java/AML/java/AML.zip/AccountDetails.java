public class AccountDetails{
    public String cardNumber;
    public Metadata @metadata;
}
