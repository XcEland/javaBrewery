public class CountryCode{
    public String countryCodeValue;
    public Metadata @metadata;
    public String countryCodeSource;
}
