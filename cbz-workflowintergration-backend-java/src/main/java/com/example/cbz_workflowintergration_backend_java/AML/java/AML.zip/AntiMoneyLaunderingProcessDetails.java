public class AntiMoneyLaunderingProcessDetails{
    public ProcessContext processContext;
    public AmlReviewDetails amlReviewDetails;
    public IdentityDetails identityDetails;
    public ResidentialDetails residentialDetails;
    public EmploymentDetails employmentDetails;
    public SourceOfFunds sourceOfFunds;
    public UploadedDocument uploadedDocument;
    public AmlProcessFlowStatus amlProcessFlowStatus;
    public PipDetails pipDetails;
    public Metadata @metadata;
}
