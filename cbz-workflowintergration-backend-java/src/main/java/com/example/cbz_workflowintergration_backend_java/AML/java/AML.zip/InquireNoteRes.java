public class InquireNoteRes{
    public NoteInfo noteInfo;
    public Metadata @metadata;
}
