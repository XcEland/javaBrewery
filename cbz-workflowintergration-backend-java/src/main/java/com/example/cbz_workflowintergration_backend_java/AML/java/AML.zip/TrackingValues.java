public class TrackingValues{
    @JsonProperty("IDdocumentId") 
    public String iDdocumentId;
    public String addressDocumentId;
    public String sourceOfFundsDescription;
    public String sourceOfFundsAmount;
    public String amendmentType;
    public String amountChanged;
    public Metadata @metadata;
}
