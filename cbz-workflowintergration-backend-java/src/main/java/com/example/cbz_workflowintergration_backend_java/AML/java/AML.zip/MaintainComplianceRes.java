public class MaintainComplianceRes{
    public ResponseStatus responseStatus;
    public ComplianceRecord complianceRecord;
    public Metadata @metadata;
    public ComplianceStatusRecord complianceStatusRecord;
}
