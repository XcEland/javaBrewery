public class ResponseHeader{
    public ResponseBO responseBO;
    public Metadata @metadata;
}
