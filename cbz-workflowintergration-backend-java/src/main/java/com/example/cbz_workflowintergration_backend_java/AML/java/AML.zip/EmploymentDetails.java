public class EmploymentDetails{
    public String employerName;
    public String industry;
    public String industryDesc;
    public String designation;
    public String designationDesc;
    public String employmentType;
    public String employmentTypeDescription;
    public boolean staffInd;
    public String employmentStatus;
    public String employmentStatusDesc;
    public UnemploymentDetails unemploymentDetails;
    public Metadata @metadata;
}
