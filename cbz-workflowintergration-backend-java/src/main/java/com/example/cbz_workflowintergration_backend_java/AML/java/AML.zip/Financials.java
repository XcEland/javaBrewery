public class Financials{
    public Expense expense;
    public Income income;
    public String numberOfMonths;
    public int totalYearsEmployed;
    public String financialsSigned;
    public Metadata @metadata;
}
