public class AmlIntegrationDetails{
    public GetCustomerInput getCustomerInput;
    public GetCustomerRelatedPartiesOutput getCustomerRelatedPartiesOutput;
    public NonBiometricDHAOutput nonBiometricDHAOutput;
    public Object displayNotes;
    public InquireNoteRes inquireNoteRes;
    public MaintainComplianceRes maintainComplianceRes;
    public DocumentBoForTable documentBoForTable;
    public Metadata @metadata;
}
