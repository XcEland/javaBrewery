public class SoleProprietor{
    public Employment employment;
    public Financials financials;
    public Metadata @metadata;
}
