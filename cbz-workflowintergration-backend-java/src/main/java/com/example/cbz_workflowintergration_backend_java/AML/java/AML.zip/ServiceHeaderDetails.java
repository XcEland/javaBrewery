public class ServiceHeaderDetails{
    public String callerId;
    public String processInstanceId;
    public String loggedInUserName;
    public String logLevel;
    public String callerVersion;
    public String screenName;
    public String bpmProcessName;
    public String serviceName;
    public Metadata @metadata;
}
