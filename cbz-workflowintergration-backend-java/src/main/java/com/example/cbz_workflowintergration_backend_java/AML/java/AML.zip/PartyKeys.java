public class PartyKeys{
    public String partyId;
    public Metadata @metadata;
    public SvcIdent svcIdent;
    public LoginIdent loginIdent;
}
