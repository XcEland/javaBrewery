public class Registration{
    public String registeredName;
    public String registrationDate;
    public String tradingName;
    public String previousName;
    public Metadata @metadata;
}
