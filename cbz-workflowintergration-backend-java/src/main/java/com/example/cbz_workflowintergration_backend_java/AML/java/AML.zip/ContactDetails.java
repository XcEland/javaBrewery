public class ContactDetails{
    public String homePhoneNumber;
    public String workPhoneNumber;
    public String cellPhoneNumber;
    public String emailAddress;
    public Metadata @metadata;
    public Physical physical;
    public Electronic electronic;
}
