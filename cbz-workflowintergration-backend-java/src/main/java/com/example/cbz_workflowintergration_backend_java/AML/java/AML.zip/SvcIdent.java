public class SvcIdent{
    public String svcProviderName;
    public String svcName;
    public Metadata @metadata;
}
