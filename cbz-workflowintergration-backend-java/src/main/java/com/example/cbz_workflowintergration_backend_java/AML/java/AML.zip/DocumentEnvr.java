public class DocumentEnvr{
    public Date createdDate;
    public String creationUserId;
    public Metadata @metadata;
    public String lastUpdateDate;
    public String lastChangeUserId;
}
