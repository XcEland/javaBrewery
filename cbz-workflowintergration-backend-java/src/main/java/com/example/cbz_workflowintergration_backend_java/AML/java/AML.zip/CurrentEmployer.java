public class CurrentEmployer{
    public String occupationStatus;
    public String employerName;
    public Address address;
    public String designation;
    public int yearsAtEmployer;
    public String occupationIndustry;
    public String workNumber;
    public Metadata @metadata;
}
