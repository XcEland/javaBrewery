public class EmailProcessBO{
    public String emailtype;
    public MessageContent messageContent;
    public String templateName;
    public Metadata @metadata;
}
