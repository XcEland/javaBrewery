public class UnemploymentDetails{
    public String unemploymentReason;
    public Date unemploymentStartDate;
    public Object unemploymentEndDate;
    public String unemploymentTypeDescription;
    public String orgCatIdentValue;
    public String occupation;
    public Metadata @metadata;
}
