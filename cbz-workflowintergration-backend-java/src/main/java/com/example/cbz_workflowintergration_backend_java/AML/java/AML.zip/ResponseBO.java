public class ResponseBO{
    public String id;
    public String statusCode;
    public String statusDescription;
    public String serverStatusCode;
    public String severity;
    public Metadata @metadata;
}
