public class NonBiometricDHAOutput{
    public ResponseHeader responseHeader;
    public GetDataResponse getDataResponse;
    public Metadata @metadata;
}
