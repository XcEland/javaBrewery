public class CustomerDetails{
    public String firstName;
    public String middleName;
    public String lastName;
    public String idType;
    public String idNumber;
    public String gender;
    public String countryOfResidence;
    public String title;
    public String bpId;
    public String nationality;
    public Metadata @metadata;
}
