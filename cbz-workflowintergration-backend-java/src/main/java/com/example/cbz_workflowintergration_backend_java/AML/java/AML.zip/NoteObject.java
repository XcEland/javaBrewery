public class NoteObject{
    public NoteType noteType;
    public String linkedObjectId;
    public Metadata @metadata;
}
