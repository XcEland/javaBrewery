public class ComplianceRecord{
    public PartyKeys partyKeys;
    public ComplianceInfo complianceInfo;
    public Metadata @metadata;
    public CompliancePartyInfo compliancePartyInfo;
}
