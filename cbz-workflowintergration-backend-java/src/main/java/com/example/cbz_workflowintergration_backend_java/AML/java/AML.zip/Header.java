public class Header{
    public String kycStatus;
    public String accountNumber;
    public String customerType;
    public String marketSegment;
    public String applicationNumber;
    public String debtReview;
    public Entity entity;
    public Customer customer;
    public String bpdid;
    public String accountExecutive;
    public Metadata @metadata;
}
