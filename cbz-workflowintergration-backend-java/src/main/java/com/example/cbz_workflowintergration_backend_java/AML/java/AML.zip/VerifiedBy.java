public class VerifiedBy{
    public String verifiedByAcquirerIdent;
    public Date verificationDate;
    public String sourceSystem;
    public Metadata @metadata;
    public String sourceSystemName;
}
