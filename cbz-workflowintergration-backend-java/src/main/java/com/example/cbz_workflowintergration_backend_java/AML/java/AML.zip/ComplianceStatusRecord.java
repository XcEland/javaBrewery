public class ComplianceStatusRecord{
    public PartyKeys partyKeys;
    public ComplianceRoleStatus complianceRoleStatus;
    public Metadata @metadata;
}
