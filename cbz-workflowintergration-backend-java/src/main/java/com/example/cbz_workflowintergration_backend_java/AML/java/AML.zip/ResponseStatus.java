public class ResponseStatus{
    public String statusCode;
    public String serverStatusCode;
    public String severity;
    public Metadata @metadata;
    public String id;
    public String statusDescription;
}
