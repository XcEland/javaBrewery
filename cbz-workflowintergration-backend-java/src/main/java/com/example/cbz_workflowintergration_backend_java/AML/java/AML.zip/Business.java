public class Business{
    public String businessStatusDate;
    public String businessType;
    public String businessStartDate;
    public String businessStatus;
    public Metadata @metadata;
}
