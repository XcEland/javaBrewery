public class ReasonForRejection{
    public Reject reject;
    public String approve;
    public Metadata @metadata;
}
