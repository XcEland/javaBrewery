public class AmlProcessFlowStatus{
    public String flowAction;
    public String previousUser;
    public String amlReview;
    public String previousUserPendTask;
    public Metadata @metadata;
}
