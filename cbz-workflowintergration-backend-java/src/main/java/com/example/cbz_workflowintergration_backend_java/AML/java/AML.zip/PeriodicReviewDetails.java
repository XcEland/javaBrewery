public class PeriodicReviewDetails{
    public String periodicFrequency;
    public Object dueDate;
    public Metadata @metadata;
}
