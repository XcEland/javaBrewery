public class LanguageCode{
    public String code;
    public String description;
    public Metadata @metadata;
}
