public class Electronic{
    public String fax;
    public String cellNumber;
    public String emailAddress;
    public String landline2;
    public String landline1;
    public Metadata @metadata;
}
