public class NoteInfo{
    public NoteObject noteObject;
    public NoteCategoryInfo noteCategoryInfo;
    public String noteCreatedBy;
    public String noteDate;
    public String noteTime;
    public String noteText;
    public LanguageCode languageCode;
    public Metadata @metadata;
}
