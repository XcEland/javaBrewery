public class EscalationBO{
    public Date reminderDay7;
    public Date expirySetDate;
    public int expiryCount;
    public Metadata @metadata;
}
