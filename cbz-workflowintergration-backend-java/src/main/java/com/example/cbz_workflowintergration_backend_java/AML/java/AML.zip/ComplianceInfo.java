public class ComplianceInfo{
    public Date lastAssessDate;
    public ComplianceVerificationData complianceVerificationData;
    public ComplianceRoleStatus complianceRoleStatus;
    public Metadata @metadata;
    public boolean exemptionIndicator;
}
