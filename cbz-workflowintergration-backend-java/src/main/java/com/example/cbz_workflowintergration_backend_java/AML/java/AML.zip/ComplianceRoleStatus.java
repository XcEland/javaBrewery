public class ComplianceRoleStatus{
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
    public String complianceRole;
    public String description;
    public CountryCode countryCode;
    public ComplianceStatus complianceStatus;
}
