public class Expense{
    public int totalMonthlyExpense;
    public int monthlyLivingExpense;
    public Metadata @metadata;
}
