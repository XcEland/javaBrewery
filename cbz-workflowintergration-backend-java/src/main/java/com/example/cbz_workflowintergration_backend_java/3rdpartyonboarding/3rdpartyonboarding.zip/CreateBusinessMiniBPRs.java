public class CreateBusinessMiniBPRs{
    public boolean isBPCreated;
    public String bpID;
    public String responseStatus;
    public Metadata @metadata;
}
