public class PublicOfficialRelatedDetails{
    public boolean relatedToPublicOfficial;
    public Object name;
    public Object surname;
    public Object typeOfRelationship;
    public Metadata @metadata;
}
