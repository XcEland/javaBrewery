public class ServiceResponse{
    public String statusCode;
    public String statusDescription;
    public Metadata @metadata;
}
