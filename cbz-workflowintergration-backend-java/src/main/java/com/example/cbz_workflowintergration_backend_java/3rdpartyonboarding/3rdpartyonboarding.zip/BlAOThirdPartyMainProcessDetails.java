public class BlAOThirdPartyMainProcessDetails{
    public String processStateCode;
    public String processStateDescription;
    public Date processEndDateAndTime;
    public String bankGeneratedReferenceNumber;
    public String productID;
    public double requestedLoanAmount;
    public boolean isStoreToDB;
    public VerifyCustomerRq verifyCustomerRq;
    public VerifyCustomerRs verifyCustomerRs;
    public OriginateCustomerRq originateCustomerRq;
    public OriginateCustomerRs originateCustomerRs;
    public CreateQuoteRq createQuoteRq;
    public CreateQuoteRs createQuoteRs;
    public StoreToDataBaseRs storeToDataBaseRs;
    public Metadata @metadata;
}
