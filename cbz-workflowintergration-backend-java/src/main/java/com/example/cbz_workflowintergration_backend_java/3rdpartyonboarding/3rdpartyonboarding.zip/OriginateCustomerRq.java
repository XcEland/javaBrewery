public class OriginateCustomerRq{
    public ProcessContext processContext;
    public HeaderDetails headerDetails;
    public DirectorDetails directorDetails;
    public BusinessEntityDetails businessEntityDetails;
    public boolean isCreateBusinessBP;
    public boolean isCreateRelatedPartiesBP;
    public Metadata @metadata;
}
