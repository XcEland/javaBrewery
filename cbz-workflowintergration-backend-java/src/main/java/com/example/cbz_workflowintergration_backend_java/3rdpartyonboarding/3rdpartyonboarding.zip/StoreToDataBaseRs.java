public class StoreToDataBaseRs{
    public boolean isStoreToDatabaseSuccess;
    public String responseInJSONString;
    public String response;
    public HeaderDetailsJSON headerDetailsJSON;
    public String errorBO;
    public String businessFunction;
    public String startTime;
    public String endTime;
    public Metadata @metadata;
}
