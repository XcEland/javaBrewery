public class CreateQuoteRs{
    public CreateQuoteServiceResponse createQuoteServiceResponse;
    public Metadata @metadata;
}
