public class HeaderDetails{
    public String requestCorrelation;
    public String digitalId;
    public Object respondToAddress;
    public Object accessToken;
    public boolean isSynchronous;
    public String channelId;
    public String requestTraceId;
    public Metadata @metadata;
    public String bankGeneratedReferenceNumber;
    public String businessStatusCode;
    public String businessStatusDescription;
    public Date requestTimeStamp;
}
