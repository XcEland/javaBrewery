public class ObjectKeys{
    public Object primaryId;
    public Object primaryType;
    public ObjectRef objectRef;
    public Metadata @metadata;
}
