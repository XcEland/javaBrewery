public class OriginateCustomerRs{
    public CreateBusinessMiniBPRs createBusinessMiniBPRs;
    public CreateRelatedPartiesMiniBPRs createRelatedPartiesMiniBPRs;
    public boolean isCreateBusinessMiniBPSuccess;
    public boolean isCreateRelatedPartiesMiniBPSuccess;
    public Metadata @metadata;
}
