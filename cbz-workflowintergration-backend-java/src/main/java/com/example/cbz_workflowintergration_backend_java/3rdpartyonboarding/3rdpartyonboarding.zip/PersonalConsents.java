public class PersonalConsents{
    public boolean originatorIdentityFraudCheck;
    public boolean originatorCreditBureauCheck;
    public Metadata @metadata;
}
