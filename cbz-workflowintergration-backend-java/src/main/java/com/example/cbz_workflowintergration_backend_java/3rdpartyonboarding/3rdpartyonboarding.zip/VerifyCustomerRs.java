public class VerifyCustomerRs{
    public FindTargetBPBusinessRs findTargetBPBusinessRs;
    public FindTargetBPRelatedPartiesRs findTargetBPRelatedPartiesRs;
    public Object complianceCheckBusinessRs;
    public Object complianceCheckRelatedPartiesRs;
    public Object dhaValidationRs;
    public boolean isVerifyBusinessSuccess;
    public boolean isVerifyRelatedPartiedSuccess;
    public boolean isCreateBusinessBP;
    public boolean isCreateRelatedPartiesBP;
    public boolean isFindOpenApplications;
    public Metadata @metadata;
}
