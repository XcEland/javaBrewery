public class CreateQuoteRq{
    public ProcessContext processContext;
    public HeaderDetails headerDetails;
    public CompanyDetails companyDetails;
    public QuoteDetails quoteDetails;
    public Metadata @metadata;
}
