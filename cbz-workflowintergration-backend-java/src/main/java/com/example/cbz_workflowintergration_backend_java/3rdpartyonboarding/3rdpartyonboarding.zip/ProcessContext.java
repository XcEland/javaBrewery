public class ProcessContext{
    public String msgGroupReference;
    public Object clientTerminalSeqNum;
    public Object partyId;
    public String bpdName;
    public NetworkTrnData networkTrnData;
    public ClientApp clientApp;
    public ObjectKeys objectKeys;
    public Metadata @metadata;
}
