public class QuoteDetails{
    public ProductDetails productDetails;
    public Affordability affordability;
    public String quoteReferenceNumber;
    public Metadata @metadata;
}
