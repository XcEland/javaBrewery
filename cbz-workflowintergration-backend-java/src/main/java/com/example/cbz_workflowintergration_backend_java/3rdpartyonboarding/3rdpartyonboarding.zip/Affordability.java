public class Affordability{
    public double expenditureAmount;
    public double grossIncomeAmount;
    public String expenditureFrequency;
    public String incomeFrequency;
    public Metadata @metadata;
}
