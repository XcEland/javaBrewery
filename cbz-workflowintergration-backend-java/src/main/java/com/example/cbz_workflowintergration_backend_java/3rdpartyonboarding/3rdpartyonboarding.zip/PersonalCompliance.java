public class PersonalCompliance{
    public boolean originatorUsageConsent;
    public Metadata @metadata;
}
