public class CompanyDetails{
    public Object directorDetails;
    public BusinessEntityDetails businessEntityDetails;
    public Consents consents;
    public Compliance compliance;
    public Metadata @metadata;
}
