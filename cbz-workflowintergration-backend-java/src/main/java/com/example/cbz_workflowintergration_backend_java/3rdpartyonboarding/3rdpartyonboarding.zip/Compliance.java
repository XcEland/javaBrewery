public class Compliance{
    public BusinessCompliance businessCompliance;
    public PersonalCompliance personalCompliance;
    public Metadata @metadata;
}
