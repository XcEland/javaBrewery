public class Quotes{
    public String quoteStatus;
    public Metadata @metadata;
}
