public class BusinessConsents{
    public boolean businessIdentityFraudCheck;
    public boolean businessCreditBureauCheck;
    public Metadata @metadata;
}
