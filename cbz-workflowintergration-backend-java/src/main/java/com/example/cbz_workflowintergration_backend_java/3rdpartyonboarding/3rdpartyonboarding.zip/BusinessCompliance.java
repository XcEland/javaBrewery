public class BusinessCompliance{
    public boolean businessWoundDissolvedLiquid;
    public boolean businessUnableToPay;
    public boolean businessUnderDebtReview;
    public boolean businessUnderRescue;
    public Metadata @metadata;
}
