public class Root{
    public BlAOThirdPartyMainProcessDetails blAOThirdPartyMainProcessDetails;
    public BceThirdPartyAOProcessRq bceThirdPartyAOProcessRq;
    public ServiceResponse serviceResponse;
    public MapDirectorDetailsBPIDs mapDirectorDetailsBPIDs;
}
