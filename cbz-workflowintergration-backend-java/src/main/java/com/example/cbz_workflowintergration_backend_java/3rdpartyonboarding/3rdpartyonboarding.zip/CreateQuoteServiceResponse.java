public class CreateQuoteServiceResponse{
    public HeaderDetails headerDetails;
    public Quotes quotes;
    public Metadata @metadata;
}
