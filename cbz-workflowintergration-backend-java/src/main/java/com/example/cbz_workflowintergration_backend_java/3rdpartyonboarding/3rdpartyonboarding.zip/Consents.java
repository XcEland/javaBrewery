public class Consents{
    public BusinessConsents businessConsents;
    public PersonalConsents personalConsents;
    public Metadata @metadata;
}
