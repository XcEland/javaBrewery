public class BusinessEntityDetails{
    public String entityBpId;
    public String entityName;
    public String entityRegistrationNumber;
    public String entityType;
    public String tradingHistory;
    public String entitySector;
    public String businessDescription;
    public String businessRegion;
    public String businessEmail;
    public String noOfDirectors;
    public Metadata @metadata;
}
