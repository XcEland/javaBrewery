public class PipDetails{
    public boolean publicOfficial;
    public PublicOfficialRelatedDetails publicOfficialRelatedDetails;
    public Metadata @metadata;
}
