public class MarketSegment{
    public Metadata @metadata;
    public String name;
    public String value;
}
