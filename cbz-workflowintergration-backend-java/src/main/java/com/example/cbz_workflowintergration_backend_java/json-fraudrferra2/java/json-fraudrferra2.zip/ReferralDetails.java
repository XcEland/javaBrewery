public class ReferralDetails{
    public String offerId;
    public Date appDate;
    public BranchDetails branchDetails;
    public MarketSegment marketSegment;
    public String rafUniqueKey;
    public boolean fraudReferral;
    public boolean creditReferral;
    public Metadata @metadata;
}
