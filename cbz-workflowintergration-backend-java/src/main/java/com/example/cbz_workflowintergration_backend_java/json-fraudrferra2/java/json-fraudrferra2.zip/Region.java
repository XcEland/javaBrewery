public class Region{
    public String name;
    public String value;
    public Metadata @metadata;
}
