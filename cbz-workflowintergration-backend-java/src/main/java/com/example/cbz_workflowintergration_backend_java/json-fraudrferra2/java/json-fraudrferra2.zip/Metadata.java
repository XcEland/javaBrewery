public class Metadata{
    public String objectID;
    public boolean dirty;
    public boolean invalid;
    public boolean shared;
    public boolean contentObject;
    public String rootVersionContextID;
    public String className;
}
