public class ReferralRqRs{
    public ProcessContext processContext;
    public ReferralDetails referralDetails;
    public Metadata @metadata;
}
