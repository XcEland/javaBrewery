public class CustomerDetails{
    public Metadata @metadata;
}
