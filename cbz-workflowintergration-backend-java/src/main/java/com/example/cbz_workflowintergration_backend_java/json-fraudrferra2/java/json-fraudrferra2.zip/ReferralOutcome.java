public class ReferralOutcome{
    public String rafDecision;
    public ReferralDecision referralDecision;
    public AdverseReasons adverseReasons;
    public ReferralAdverseReasons referralAdverseReasons;
    public Metadata @metadata;
}
