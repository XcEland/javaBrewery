public class NoteCategoryInfo{
    public String code;
    public String description;
    public Metadata @metadata;
}
