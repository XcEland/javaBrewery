public class AdverseReasons{
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
}
