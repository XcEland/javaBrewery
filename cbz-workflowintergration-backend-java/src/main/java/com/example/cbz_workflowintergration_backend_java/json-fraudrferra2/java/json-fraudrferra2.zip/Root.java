public class Root{
    public LdapRqUserAttributes ldapRqUserAttributes;
    public String test;
    public Object logger;
    public String branchOfficerId;
    public FraudAssessmentDetails fraudAssessmentDetails;
    public String custDate;
    public int processSLA;
    public String featureTeam;
    public String msgGroupReference;
    public UsersSearchCriteria usersSearchCriteria;
    public ReferralRqRs referralRqRs;
    public String flowAction;
    public String correlationId;
    public String componentName;
    public CustomerDetails customerDetails;
    @JsonProperty("SupportTeam") 
    public String supportTeam;
}
