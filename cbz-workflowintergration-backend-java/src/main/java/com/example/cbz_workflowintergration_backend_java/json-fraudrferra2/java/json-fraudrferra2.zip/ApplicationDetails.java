public class ApplicationDetails{
    public Date appDate;
    public String appStatus;
    public String custName;
    public String custSurname;
    public String custId;
    public MarketSegment marketSegment;
    public Offer offer;
    public String debtReview;
    public CustType custType;
    public Object residentialStatus;
    public String kycStatus;
    public Object accountExecutiveDetails;
    public String bri;
    public Metadata @metadata;
}
