public class DocumentIDList{
    public ArrayList<Object> selected;
    public ArrayList<String> items;
    public Metadata @metadata;
}
