public class CreditScoringAdditonalReq{
    public General general;
    public EntityDecisons entityDecisons;
    public GeneralProductDecison generalProductDecison;
    public GeneralPrimaryDecision generalPrimaryDecision;
    public AssetDecision assetDecision;
    public EntityFraudDecision entityFraudDecision;
    public PrincipleFraudDecision principleFraudDecision;
    public String skipScorecard;
    public ExperienceReport experienceReport;
    public Optimizer optimizer;
    public Metadata @metadata;
}
