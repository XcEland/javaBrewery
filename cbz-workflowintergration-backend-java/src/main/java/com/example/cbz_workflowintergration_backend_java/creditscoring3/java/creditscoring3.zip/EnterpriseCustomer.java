public class EnterpriseCustomer{
    public EnterpriseDetails enterpriseDetails;
    public EnterpriseConsents enterpriseConsents;
    public EnterpriseAffordability enterpriseAffordability;
    public Metadata @metadata;
}
