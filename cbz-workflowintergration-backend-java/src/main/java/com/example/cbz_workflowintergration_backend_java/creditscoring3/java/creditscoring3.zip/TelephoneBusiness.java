public class TelephoneBusiness{
    public String telephoneCode;
    public String telephoneNumber;
    public Metadata @metadata;
}
