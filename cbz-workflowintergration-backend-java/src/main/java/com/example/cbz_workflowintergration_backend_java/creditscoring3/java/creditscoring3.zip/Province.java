public class Province{
    public String name;
    public Metadata @metadata;
}
