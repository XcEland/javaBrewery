public class EnterpriseAffordability{
    public double annualTurnover;
    public double annualExpenses;
    public double currentLiabilities;
    public double grossAssets;
    public Metadata @metadata;
}
