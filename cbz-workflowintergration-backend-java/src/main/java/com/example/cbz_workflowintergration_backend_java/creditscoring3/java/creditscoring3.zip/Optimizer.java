public class Optimizer{
    public String headRoom;
    public String optimizerLimit;
    public Metadata @metadata;
}
