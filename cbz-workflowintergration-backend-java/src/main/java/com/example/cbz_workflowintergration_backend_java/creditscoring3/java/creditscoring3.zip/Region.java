public class Region{
    public String name;
    public Metadata @metadata;
}
