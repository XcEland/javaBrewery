public class EntityDecisons{
    public ProductDecision productDecision;
    public PreScreenDecision preScreenDecision;
    public Metadata @metadata;
}
