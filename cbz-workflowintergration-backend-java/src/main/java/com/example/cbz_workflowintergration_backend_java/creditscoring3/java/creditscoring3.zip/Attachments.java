public class Attachments{
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
}
