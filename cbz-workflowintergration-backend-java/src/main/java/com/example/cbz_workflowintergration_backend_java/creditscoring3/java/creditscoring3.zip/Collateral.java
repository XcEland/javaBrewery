public class Collateral{
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
}
