public class Center{
    public String name;
    public Metadata @metadata;
}
