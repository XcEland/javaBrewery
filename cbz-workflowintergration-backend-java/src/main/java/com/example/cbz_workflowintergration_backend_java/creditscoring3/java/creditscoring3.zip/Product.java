public class Product{
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
}
