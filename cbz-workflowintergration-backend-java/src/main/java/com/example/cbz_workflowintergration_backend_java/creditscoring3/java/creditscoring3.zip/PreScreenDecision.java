public class PreScreenDecision{
    public String decisionCode;
    public String customerNumber;
    public String adverseCode1Product1;
    public String rollDecision;
    public Metadata @metadata;
}
