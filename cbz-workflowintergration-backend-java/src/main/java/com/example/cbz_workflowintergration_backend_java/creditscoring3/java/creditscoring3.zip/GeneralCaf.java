public class GeneralCaf{
    public String apMarketGrpCode;
    public String appType;
    public String agreementType;
    public String dicCatg;
    public double requestedLimit;
    public double initialFees;
    public double monthlySerFee;
    public Metadata @metadata;
}
