public class FraudCheckBPMData{
    public String alfaCreditRefNo;
    public String applicationId;
    public String bpGuid;
    public String partyId;
    public String msgReference;
    public boolean fraudRefIndicator;
    public boolean credRefIndicator;
    public BranchDetails branchDetails;
    public String orginatingSystem;
    public Metadata @metadata;
}
