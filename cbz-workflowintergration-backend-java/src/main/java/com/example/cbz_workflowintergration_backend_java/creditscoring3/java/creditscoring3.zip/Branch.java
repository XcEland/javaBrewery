public class Branch{
    public String name;
    public Metadata @metadata;
}
