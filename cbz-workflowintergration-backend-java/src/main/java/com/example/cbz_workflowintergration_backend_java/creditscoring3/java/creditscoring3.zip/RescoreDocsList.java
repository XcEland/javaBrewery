public class RescoreDocsList{
    public Attachments attachments;
    public Metadata @metadata;
}
