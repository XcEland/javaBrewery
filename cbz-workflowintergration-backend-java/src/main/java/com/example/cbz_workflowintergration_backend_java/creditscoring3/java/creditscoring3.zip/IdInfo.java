public class IdInfo{
    public String idType;
    public String idNo;
    public String customerNo;
    public Metadata @metadata;
}
