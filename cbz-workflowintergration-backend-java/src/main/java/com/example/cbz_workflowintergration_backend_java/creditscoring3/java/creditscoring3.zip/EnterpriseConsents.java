public class EnterpriseConsents{
    public String underDebtReview;
    public String underSequestration;
    public String underAdminOrder;
    public String extBureauConsent;
    public String businessRescue;
    public String insolvement;
    public Metadata @metadata;
}
