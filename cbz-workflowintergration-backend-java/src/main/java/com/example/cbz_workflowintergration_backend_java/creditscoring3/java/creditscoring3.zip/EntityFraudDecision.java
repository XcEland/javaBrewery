public class EntityFraudDecision{
    public String decision;
    public String customerNumber;
    public String rollUp;
    public Metadata @metadata;
}
