public class Address{
    public String line1;
    public String line2;
    public String suburb;
    public String city;
    public String postalCode;
    public Metadata @metadata;
}
