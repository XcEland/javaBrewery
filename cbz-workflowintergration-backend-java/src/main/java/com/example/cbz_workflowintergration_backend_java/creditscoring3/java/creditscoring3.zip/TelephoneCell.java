public class TelephoneCell{
    public String telephoneCode;
    public String telephoneNumber;
    public Metadata @metadata;
}
