public class ProductDecision{
    public String decisionCode;
    public String customerNumber;
    public String adverseCode1Product1;
    public String adverseCode2Product1;
    public String adverseCode3Product1;
    public String adverseCode4Product1;
    public String adverseCode5Product1;
    public String adverseCode6Product1;
    public String adverseCode7Product1;
    public String adverseCode8Product1;
    public String adverseCode9Product1;
    public String adverseCode10Product1;
    public String verificationCode;
    public String rollDecision;
    public Metadata @metadata;
}
