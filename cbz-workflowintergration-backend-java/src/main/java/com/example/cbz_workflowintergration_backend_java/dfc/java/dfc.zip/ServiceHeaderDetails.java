public class ServiceHeaderDetails{
    public Metadata @metadata;
    public String callerId;
    public String callerVersion;
    public String bpmProcessName;
    public String processInstanceId;
    public String loggedInUserName;
    public String screenName;
    public String serviceName;
    public String logLevel;
}
