public class AutoCardLinkDetails{
    public CardLinkingReq cardLinkingReq;
    public CardLinkingRes cardLinkingRes;
    public CardLinkingErrorDetails cardLinkingErrorDetails;
    public Metadata @metadata;
}
