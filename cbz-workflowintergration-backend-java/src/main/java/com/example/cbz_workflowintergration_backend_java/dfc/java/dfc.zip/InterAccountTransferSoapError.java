public class InterAccountTransferSoapError{
    public Metadata @metadata;
}
