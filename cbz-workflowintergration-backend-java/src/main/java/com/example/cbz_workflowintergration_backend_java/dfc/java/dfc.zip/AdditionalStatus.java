public class AdditionalStatus{
    @JsonProperty("SubjectElement") 
    public SubjectElement subjectElement;
    public Metadata @metadata;
}
