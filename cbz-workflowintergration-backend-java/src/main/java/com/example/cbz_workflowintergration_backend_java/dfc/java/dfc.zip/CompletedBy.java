public class CompletedBy{
    public Metadata @metadata;
}
