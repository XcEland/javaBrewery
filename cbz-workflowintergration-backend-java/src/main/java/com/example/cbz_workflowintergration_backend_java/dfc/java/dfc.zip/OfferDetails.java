public class OfferDetails{
    public String offerId;
    public String offerStatus;
    public OfferDetails offerDetails;
    public String applicationDate;
    public String applicationTime;
    public double totalExposure;
    public double totalSelectedAmount;
    public double totalMonthlyRepayment;
    public double surplusAmount;
    public Metadata @metadata;
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
}
