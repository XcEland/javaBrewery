public class OccupationStatus{
    public String name;
    public String value;
    public Metadata @metadata;
}
