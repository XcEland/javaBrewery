public class DateX{
    public Metadata @metadata;
}
