public class InterAccountResponseInfo2{
    @JsonProperty("DateX") 
    public DateX dateX;
    @JsonProperty("Personal") 
    public Personal personal;
    public Metadata @metadata;
}
