public class CardLinking{
    public String zzbCardNbr;
    public String zzbCardType;
    public String zzbAccType;
    public String zzbMnthLimit;
    public String zzbDailyLimit;
    public String zzbRefNumber;
    public Metadata @metadata;
}
