public class CardLinkingErrorDetails{
    public Metadata @metadata;
}
