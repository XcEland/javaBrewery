public class Product{
    public Metadata @metadata;
}
