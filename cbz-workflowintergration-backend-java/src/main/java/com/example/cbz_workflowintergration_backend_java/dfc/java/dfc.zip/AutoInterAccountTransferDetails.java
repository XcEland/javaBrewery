public class AutoInterAccountTransferDetails{
    public InterAccountTransferReq interAccountTransferReq;
    public InterAccountTransferRes interAccountTransferRes;
    public InterAccountTransferSoapError interAccountTransferSoapError;
    public Metadata @metadata;
}
