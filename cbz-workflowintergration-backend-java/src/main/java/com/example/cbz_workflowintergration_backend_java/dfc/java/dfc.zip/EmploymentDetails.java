public class EmploymentDetails{
    public CurrentEmployer currentEmployer;
    public PreviousEmployer previousEmployer;
    public Metadata @metadata;
}
