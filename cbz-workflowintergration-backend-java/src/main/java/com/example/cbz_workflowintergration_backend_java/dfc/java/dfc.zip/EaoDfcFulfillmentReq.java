public class EaoDfcFulfillmentReq{
    public ProcessContext processContext;
    public String offerId;
    public String bpId;
    public Conditions conditions;
    public ChannelDetails channelDetails;
    public MarketSegment marketSegment;
    public CenterType centerType;
    public Metadata @metadata;
}
