public class HeaderDetails{
    public String bpId;
    public String offerId;
    public MarketSegment marketSegment;
    public Metadata @metadata;
}
