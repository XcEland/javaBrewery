public class VarPortions{
    public ArrayList<Object> selected;
    public ArrayList<Object> items;
    public Metadata @metadata;
}
