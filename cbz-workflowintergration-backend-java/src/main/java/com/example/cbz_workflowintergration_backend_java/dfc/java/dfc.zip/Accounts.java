public class Accounts{
    public Metadata @metadata;
}
