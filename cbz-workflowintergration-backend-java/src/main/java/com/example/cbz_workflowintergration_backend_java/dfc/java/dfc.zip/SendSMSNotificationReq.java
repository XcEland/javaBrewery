public class SendSMSNotificationReq{
    public ServiceHeaderDetails serviceHeaderDetails;
    public Metadata @metadata;
}
