public class AccountResponseInfo{
    @JsonProperty("VarPortions") 
    public VarPortions varPortions;
    public Metadata @metadata;
}
