public class Financials{
    public Date incomeUpdatedDate;
    public double grossMonthlySalary;
    public double totalMonthlyIncome;
    public double otherMonthlyIncome;
    public double totalMonthlyExpenses;
    public double livingMonthlyExpenses;
    public int _totalYearsEmployes;
    public Metadata @metadata;
}
