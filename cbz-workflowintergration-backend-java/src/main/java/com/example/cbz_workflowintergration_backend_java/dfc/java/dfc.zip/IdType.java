public class IdType{
    public String value;
    public Metadata @metadata;
}
