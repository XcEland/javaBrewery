public class TransferDetails{
    public TransferFrom transferFrom;
    public TransferTo transferTo;
    public Metadata @metadata;
}
