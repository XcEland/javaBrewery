public class InteraccountResponseInfo{
    public Metadata @metadata;
}
