public class DisbursementDetails{
    public InterAccountTransferDetails interAccountTransferDetails;
    public Metadata @metadata;
}
