public class OccupationIndustry{
    public String value;
    public Metadata @metadata;
}
