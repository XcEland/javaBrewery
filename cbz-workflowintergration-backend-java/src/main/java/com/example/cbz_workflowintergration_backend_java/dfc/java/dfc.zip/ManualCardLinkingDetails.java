public class ManualCardLinkingDetails{
    public Object consultantName;
    public String status;
    public String failureCode;
    public String failureDescription;
    public DetailsOfLink detailsOfLink;
    public Metadata @metadata;
}
