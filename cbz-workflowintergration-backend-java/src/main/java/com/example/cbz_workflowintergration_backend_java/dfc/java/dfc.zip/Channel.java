public class Channel{
    public String originatingChannel;
    public String description;
    public Metadata @metadata;
}
