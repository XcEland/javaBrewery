public class AccountInfoDetails{
    public RetrieveAccountInfoReq retrieveAccountInfoReq;
    public RetrieveAccountInfoRes retrieveAccountInfoRes;
    public RetrieveAccountInfoErrorDetails retrieveAccountInfoErrorDetails;
    public Metadata @metadata;
}
