public class ManualInterAccountTransferDetails{
    public TransferDetails transferDetails;
    public Metadata @metadata;
}
