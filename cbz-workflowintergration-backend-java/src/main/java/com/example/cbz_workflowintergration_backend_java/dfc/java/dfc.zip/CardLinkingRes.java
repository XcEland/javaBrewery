public class CardLinkingRes{
    public Metadata @metadata;
}
