public class FulfilmentRelease{
    public AccountInfoDetails accountInfoDetails;
    public CardLinkingDetails cardLinkingDetails;
    public FulfilmentNotification fulfilmentNotification;
    public DisbursementDetails disbursementDetails;
    public Metadata @metadata;
}
