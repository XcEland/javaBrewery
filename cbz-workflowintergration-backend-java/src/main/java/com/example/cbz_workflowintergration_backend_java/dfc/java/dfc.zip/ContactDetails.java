public class ContactDetails{
    public String homeNumber;
    public PreferredContactType preferredContactType;
    public Metadata @metadata;
}
