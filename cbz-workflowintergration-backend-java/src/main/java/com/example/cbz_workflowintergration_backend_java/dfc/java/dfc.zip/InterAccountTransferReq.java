public class InterAccountTransferReq{
    public AccountTypeTo accountTypeTo;
    public ServiceHeaderDetails serviceHeaderDetails;
    public AccountTypeFrom accountTypeFrom;
    public Metadata @metadata;
}
