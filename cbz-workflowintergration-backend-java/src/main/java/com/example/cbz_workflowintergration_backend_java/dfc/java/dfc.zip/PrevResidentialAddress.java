public class PrevResidentialAddress{
    public Metadata @metadata;
}
