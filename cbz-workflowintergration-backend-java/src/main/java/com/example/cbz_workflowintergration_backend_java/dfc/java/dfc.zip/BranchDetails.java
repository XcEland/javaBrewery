public class BranchDetails{
    public Metadata @metadata;
}
