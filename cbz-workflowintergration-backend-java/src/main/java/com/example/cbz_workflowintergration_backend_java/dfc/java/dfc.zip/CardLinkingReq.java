public class CardLinkingReq{
    public Metadata @metadata;
}
