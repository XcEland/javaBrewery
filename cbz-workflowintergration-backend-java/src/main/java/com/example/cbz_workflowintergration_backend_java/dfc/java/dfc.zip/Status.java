public class Status{
    @JsonProperty("AdditionalStatus") 
    public AdditionalStatus additionalStatus;
    public Metadata @metadata;
}
