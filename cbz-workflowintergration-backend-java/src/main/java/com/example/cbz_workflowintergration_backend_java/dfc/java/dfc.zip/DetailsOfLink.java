public class DetailsOfLink{
    public String cardNumber;
    public String accountNumber;
    public String position;
    public Metadata @metadata;
}
