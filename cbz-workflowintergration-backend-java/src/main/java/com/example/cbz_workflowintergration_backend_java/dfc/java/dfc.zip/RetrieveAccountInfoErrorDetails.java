public class RetrieveAccountInfoErrorDetails{
    public Metadata @metadata;
}
