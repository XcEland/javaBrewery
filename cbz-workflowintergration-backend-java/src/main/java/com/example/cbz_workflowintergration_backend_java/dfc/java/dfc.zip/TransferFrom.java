public class TransferFrom{
    public String accountNumber;
    public Metadata @metadata;
}
