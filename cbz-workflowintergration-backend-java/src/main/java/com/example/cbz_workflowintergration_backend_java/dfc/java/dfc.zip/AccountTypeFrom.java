public class AccountTypeFrom{
    public Metadata @metadata;
}
