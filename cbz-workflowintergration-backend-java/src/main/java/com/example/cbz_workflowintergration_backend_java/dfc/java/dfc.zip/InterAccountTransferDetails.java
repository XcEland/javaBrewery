public class InterAccountTransferDetails{
    public AutoInterAccountTransferDetails autoInterAccountTransferDetails;
    public ManualInterAccountTransferDetails manualInterAccountTransferDetails;
    public boolean fundstransferred;
    public Metadata @metadata;
}
