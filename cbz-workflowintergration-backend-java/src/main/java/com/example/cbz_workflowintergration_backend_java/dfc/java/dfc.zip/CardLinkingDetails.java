public class CardLinkingDetails{
    public AutoCardLinkDetails autoCardLinkDetails;
    public ManualCardLinkingDetails manualCardLinkingDetails;
    public boolean rcpLinkedToCard;
    public Metadata @metadata;
}
