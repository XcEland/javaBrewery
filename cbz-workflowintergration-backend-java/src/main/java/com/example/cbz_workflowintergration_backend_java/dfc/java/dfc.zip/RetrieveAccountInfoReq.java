public class RetrieveAccountInfoReq{
    public ServiceHeaderDetails serviceHeaderDetails;
    public Accounts accounts;
    public Metadata @metadata;
}
