public class GetAfforadabilityRes{
    public double totalIncome;
    public double totalExpense;
    public Metadata @metadata;
}
