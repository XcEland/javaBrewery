public class MsgRsHdr{
    @JsonProperty("ContextRsHdr") 
    public ContextRsHdr contextRsHdr;
    public Metadata @metadata;
}
