public class AccommodationType{
    public String name;
    public Metadata @metadata;
}
