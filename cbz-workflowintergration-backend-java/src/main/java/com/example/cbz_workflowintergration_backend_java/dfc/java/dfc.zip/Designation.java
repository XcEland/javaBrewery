public class Designation{
    public String value;
    public Metadata @metadata;
}
