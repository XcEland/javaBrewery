public class OriginatingProcessChannel{
    public String originatingChannel;
    public Product product;
    public double existingLimit;
    public OriginatingProcess originatingProcess;
    public Metadata @metadata;
}
