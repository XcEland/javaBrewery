public class SubjectElement{
    public Metadata @metadata;
}
