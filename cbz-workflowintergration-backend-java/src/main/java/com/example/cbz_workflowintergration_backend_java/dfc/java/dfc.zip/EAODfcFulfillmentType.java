public class EAODfcFulfillmentType{
    public String channel;
    public HeaderDetails headerDetails;
    public CustomerDetails customerDetails;
    public OfferDetails offerDetails;
    public Condition condition;
    public BranchDetails branchDetails;
    public FulfilmentRelease fulfilmentRelease;
    public Metadata @metadata;
}
