public class CenterType{
    public String name;
    public String value;
    public Metadata @metadata;
}
