public class CurrentEmployer{
    public int years;
    public Address address;
    public Object workNumber;
    public OccupationStatus occupationStatus;
    public Designation designation;
    public OccupationIndustry occupationIndustry;
    public String _employerName;
    public Date employmentStartDate;
    public Date employmentEndDate;
    public Metadata @metadata;
}
