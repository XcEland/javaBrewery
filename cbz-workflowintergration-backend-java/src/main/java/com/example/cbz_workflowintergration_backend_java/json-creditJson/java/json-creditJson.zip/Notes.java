public class Notes{
    public ArrayList<Object> selected;
    public ArrayList<String> items;
    public Metadata @metadata;
}
