public class Root{
    public CreditAssessmentDetails creditAssessmentDetails;
    public LdapRqUserAttributes ldapRqUserAttributes;
    public String originatingOfficerID;
    public TaskData taskData;
    public LdapRsUserAttributes ldapRsUserAttributes;
    public String branchOfficerId;
    public Object employmentStartDate;
    public String msgGroupReference;
    public LdapUser ldapUser;
    public UsersSearchCriteria usersSearchCriteria;
    public ReferralRqRs referralRqRs;
    public Object employmentEndDate;
    public String flowAction;
    public CustomerDetails customerDetails;
}
