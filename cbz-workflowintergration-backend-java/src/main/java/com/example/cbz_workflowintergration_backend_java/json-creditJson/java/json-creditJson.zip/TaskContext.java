public class TaskContext{
    public SearchContext searchContext;
    public String flowAction;
    public String channelUser;
    public String backofficeUser;
    public String mcaScreenId;
    public Metadata @metadata;
}
