public class NoteInfo{
    public NoteObject noteObject;
    public NoteCategoryInfo noteCategoryInfo;
    public String noteCreatedBy;
    public Date noteDate;
    public Date noteTime;
    public String noteText;
    public LanguageCode languageCode;
    public Metadata @metadata;
}
