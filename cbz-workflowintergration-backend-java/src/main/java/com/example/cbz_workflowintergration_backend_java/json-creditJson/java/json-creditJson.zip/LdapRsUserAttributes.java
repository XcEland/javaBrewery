public class LdapRsUserAttributes{
    @JsonProperty("Sello.Mogashane@standardbank.co.za") 
    public SelloMogashaneStandardbankCoZa sello.Mogashane@standardbank.co.za;
}
