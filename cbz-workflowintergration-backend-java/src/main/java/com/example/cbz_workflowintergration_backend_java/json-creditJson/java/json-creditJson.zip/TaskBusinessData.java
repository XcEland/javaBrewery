public class TaskBusinessData{
    public HeaderDetails headerDetails;
    public String businessDataAsJSON;
    public Metadata @metadata;
}
