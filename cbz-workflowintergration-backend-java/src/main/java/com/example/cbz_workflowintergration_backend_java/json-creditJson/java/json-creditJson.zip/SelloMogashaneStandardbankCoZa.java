public class SelloMogashaneStandardbankCoZa{
    public String uid;
    public String uniqueName;
    public String externalName;
    public String repositoryId;
    public String cn;
    public String sn;
}
