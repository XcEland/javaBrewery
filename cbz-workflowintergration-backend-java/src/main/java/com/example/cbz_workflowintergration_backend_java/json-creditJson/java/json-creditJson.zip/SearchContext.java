public class SearchContext{
    public String searchType;
    public String refNo;
    public String bpId;
    public String custId;
    public String atRiskTime;
    public Category category;
    public String status;
    public String manager;
    public Metadata @metadata;
}
