public class Origin{
    public String value;
    public Metadata @metadata;
}
