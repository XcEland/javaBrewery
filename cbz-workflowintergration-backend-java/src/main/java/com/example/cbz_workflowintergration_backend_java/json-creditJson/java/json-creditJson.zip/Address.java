public class Address{
    public Metadata @metadata;
}
