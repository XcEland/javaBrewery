public class CustomerDetails{
    public PersonalDetails personalDetails;
    public PrevResidentialAddress prevResidentialAddress;
    public ResidentialAddress residentialAddress;
    public PostalAddress postalAddress;
    public EmploymentDetails employmentDetails;
    public Financials financials;
    public ContactDetails contactDetails;
    public Metadata @metadata;
}
