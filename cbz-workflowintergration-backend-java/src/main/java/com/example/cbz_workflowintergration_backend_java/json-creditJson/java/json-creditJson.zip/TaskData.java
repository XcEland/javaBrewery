public class TaskData{
    public TaskContext taskContext;
    public TaskBusinessData taskBusinessData;
    public Metadata @metadata;
}
