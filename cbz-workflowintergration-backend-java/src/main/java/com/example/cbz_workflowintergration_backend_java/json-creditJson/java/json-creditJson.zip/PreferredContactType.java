public class PreferredContactType{
    public String value;
    public Metadata @metadata;
}
