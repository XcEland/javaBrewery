public class ProdCategory{
    public String name;
    public String value;
    public Metadata @metadata;
}
