public class PreviousEmployer{
    public Metadata @metadata;
}
