public class Title{
    public String name;
    public Metadata @metadata;
}
