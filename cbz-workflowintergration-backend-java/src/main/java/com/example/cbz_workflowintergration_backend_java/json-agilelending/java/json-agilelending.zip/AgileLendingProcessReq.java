public class AgileLendingProcessReq{
    public StartAgileSELendingOrigination startAgileSELendingOrigination;
    public boolean interestedInCrossSell;
    public Metadata @metadata;
}
