public class Entity{
    public Financial financial;
    public Detail detail;
    public Registration registration;
    public Business business;
    public Metadata @metadata;
    public String registrationNumber;
    public String ibtNumber;
    public String businessType;
}
