public class AgileLendingGlobalApprovalDetails{
    public String globalStatus;
    public ApproverDetails approverDetails;
    public Metadata @metadata;
}
