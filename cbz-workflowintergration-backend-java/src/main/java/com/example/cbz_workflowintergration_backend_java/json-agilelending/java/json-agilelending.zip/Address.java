public class Address{
    public String postalCode;
    public String suburb;
    public String province;
    public String streetName;
    public String city;
    public String country;
    public Metadata @metadata;
}
