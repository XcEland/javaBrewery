public class CollectionOptions{
    public ArrayList<Object> selected;
    public ArrayList<String> items;
    public Metadata @metadata;
}
