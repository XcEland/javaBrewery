public class Company{
    public String tradingName;
    @JsonProperty("CompanyRegNo") 
    public String companyRegNo;
    public Metadata @metadata;
}
