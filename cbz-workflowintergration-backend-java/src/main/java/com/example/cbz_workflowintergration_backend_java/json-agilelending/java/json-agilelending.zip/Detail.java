public class Detail{
    @JsonProperty("ISICCode") 
    public String iSICCode;
    public String countryOfOrigin;
    public Metadata @metadata;
}
