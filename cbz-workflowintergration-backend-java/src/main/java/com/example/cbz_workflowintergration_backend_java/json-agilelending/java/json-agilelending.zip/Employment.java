public class Employment{
    public CurrentEmployer currentEmployer;
    public PreviousEmployer previousEmployer;
    public int totalYearsOfExperience;
    public String financials;
    public Metadata @metadata;
}
