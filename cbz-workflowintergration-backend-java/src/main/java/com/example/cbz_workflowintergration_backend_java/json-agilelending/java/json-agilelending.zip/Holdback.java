public class Holdback{
    public String message;
    public double min;
    public double max;
    public double quoted;
    public Metadata @metadata;
}
