public class AgileLendinfOfferDetails{
    public double total;
    public Holdback holdback;
    public Amount amount;
    public DailyRepayment dailyRepayment;
    public boolean isReferenceRequired;
    public double topUpDiscount;
    public double term;
    public double interest;
    public Repayment repayment;
    public String completionDate;
    public double balanceBroughtForward;
    public boolean isTopUp;
    public String collectionOption;
    public CollectionOptions collectionOptions;
    public Accounts accounts;
    public Metadata @metadata;
}
