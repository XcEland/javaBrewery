public class DailyRepayment{
    public double lowValue;
    public double highValue;
    public Metadata @metadata;
}
