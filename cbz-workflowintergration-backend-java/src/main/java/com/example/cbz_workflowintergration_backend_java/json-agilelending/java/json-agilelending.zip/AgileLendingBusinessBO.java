public class AgileLendingBusinessBO{
    public String tradingAddress;
    public String approvalStatus;
    public String billingAccount;
    public String businessEntityBPID;
    public String legalName;
    public String tradingName;
    public String businessRegNo;
    public String businessResolution;
    public String campaignRef;
    public String telephoneNumber;
    public Metadata @metadata;
}
