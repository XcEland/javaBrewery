public class Financial{
    public String financialEffectiveDate;
    public int issueCapitalAmount;
    public String numberOfMonths;
    public String financialsSigned;
    public int authorisedCapitalAmount;
    public Metadata @metadata;
}
