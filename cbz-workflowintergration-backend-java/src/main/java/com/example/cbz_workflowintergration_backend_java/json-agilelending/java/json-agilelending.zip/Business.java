public class Business{
    public String businessStatusDate;
    public String businessType;
    public String businessStatus;
    public Metadata @metadata;
}
