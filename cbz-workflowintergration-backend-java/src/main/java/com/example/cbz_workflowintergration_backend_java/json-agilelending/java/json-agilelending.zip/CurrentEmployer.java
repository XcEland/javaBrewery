public class CurrentEmployer{
    public String occupationStatus;
    public Address address;
    public String designation;
    public int yearsAtEmployer;
    public String occupationIndustry;
    public String workNumber;
    public Metadata @metadata;
}
