public class ContactDetails{
    public Physical physical;
    public Electronic electronic;
    public Metadata @metadata;
}
