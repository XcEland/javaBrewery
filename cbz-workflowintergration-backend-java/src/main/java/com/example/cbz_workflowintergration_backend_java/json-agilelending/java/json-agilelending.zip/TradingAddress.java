public class TradingAddress{
    public String postalCode;
    public String suburb;
    public String province;
    @JsonProperty("Untitled") 
    public String untitled;
    public String streetName;
    public String city;
    public String country;
    public Metadata @metadata;
}
