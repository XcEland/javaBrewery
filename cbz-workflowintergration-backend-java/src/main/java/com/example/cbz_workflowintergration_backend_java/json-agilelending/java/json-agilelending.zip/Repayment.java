public class Repayment{
    public String footer;
    public Days days;
    public String header;
    public Metadata @metadata;
}
