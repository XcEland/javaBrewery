public class Amount{
    public String message;
    public double min;
    public double max;
    public double quoted;
    public Metadata @metadata;
}
