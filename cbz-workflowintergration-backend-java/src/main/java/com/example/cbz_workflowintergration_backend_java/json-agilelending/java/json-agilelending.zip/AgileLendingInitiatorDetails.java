public class AgileLendingInitiatorDetails{
    public String cellphoneNumber;
    public String digitalIdEmail;
    public String bpid;
    public String firstName;
    public String identificationNumber;
    public String lastName;
    public String identityType;
    public int digitalId;
    public Metadata @metadata;
}
