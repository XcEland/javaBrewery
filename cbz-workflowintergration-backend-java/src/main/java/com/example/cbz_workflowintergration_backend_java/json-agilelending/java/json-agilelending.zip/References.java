public class References{
    public double holdback;
    public double amount;
    public Company company;
    public String campaignLineReference;
    public Contacts contacts;
    public boolean isTopUp;
    public Metadata @metadata;
}
