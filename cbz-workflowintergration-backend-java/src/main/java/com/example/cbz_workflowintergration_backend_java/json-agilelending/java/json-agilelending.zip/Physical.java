public class Physical{
    public PostalAddress postalAddress;
    public RegisteredAddress registeredAddress;
    public ResidentialAddressPrevious residentialAddressPrevious;
    public TradingAddress tradingAddress;
    public ResidentialAddress residentialAddress;
    public Metadata @metadata;
}
