public class Registration{
    public String registrationDate;
    public String registeredName;
    public String tradingName;
    public String previousName;
    public Metadata @metadata;
}
