public class AgileLendingReferences{
    public References references;
    public ReferencesResponse referencesResponse;
    public Metadata @metadata;
}
