public class GetBillingAccountBranchDetails{
    public String branchName;
    public String branchCode;
    public String accountHolderName;
    public Metadata @metadata;
}
