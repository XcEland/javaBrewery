public class ApproverDetails{
    public String approvalDate;
    public String approverDigitalId;
    public String approverStatus;
    public Metadata @metadata;
}
