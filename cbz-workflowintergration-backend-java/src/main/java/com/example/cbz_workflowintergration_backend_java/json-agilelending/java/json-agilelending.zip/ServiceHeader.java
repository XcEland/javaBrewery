public class ServiceHeader{
    public String id;
    public String statusCode;
    public String serverStatusCode;
    public String severity;
    public String statusDescription;
    public Metadata @metadata;
}
