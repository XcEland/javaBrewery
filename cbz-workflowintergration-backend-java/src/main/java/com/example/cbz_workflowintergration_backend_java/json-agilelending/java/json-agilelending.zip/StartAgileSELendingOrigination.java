public class StartAgileSELendingOrigination{
    public ProcessContext processContext;
    public AgileLendingBusinessBO agileLendingBusinessBO;
    public AgileLendingInitiatorDetails agileLendingInitiatorDetails;
    public AgileLendingDirectorBO agileLendingDirectorBO;
    public AgileLendinfOfferDetails agileLendinfOfferDetails;
    public AgileLendingReferences agileLendingReferences;
    public Metadata @metadata;
}
