public class Root{
    public String businessEntityBPID;
    public String variable1;
    public Date applicationExpiryDate;
    public AgileSELendingOriginationProcessBO agileSELendingOriginationProcessBO;
    public StartAgileSELendingOrigination startAgileSELendingOrigination;
    public String campaignRef;
    public ApprovalOtp approvalOtp;
    public ApprovalHistory approvalHistory;
    public String processId;
    public String refNumber;
    public AgileLendingProcessReq agileLendingProcessReq;
    public String flowAction;
    public String referenceCode;
}
