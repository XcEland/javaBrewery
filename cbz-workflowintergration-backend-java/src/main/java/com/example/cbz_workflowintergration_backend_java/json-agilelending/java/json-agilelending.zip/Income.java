public class Income{
    public String incomeUpdatedDate;
    public int otherIncome;
    public int grossMonthlySalary;
    public int totalMonthlyIncome;
    public Metadata @metadata;
}
