public class Header{
    public String customerType;
    public String marketSegment;
    public Entity entity;
    public Customer customer;
    public String bpdid;
    public Metadata @metadata;
}
