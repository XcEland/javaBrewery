public class AgileSELendingOriginationProcessBO{
    public ProcessContext processContext;
    public AgileLendingBusinessBO agileLendingBusinessBO;
    public AgileLendingInitiatorDetails agileLendingInitiatorDetails;
    public AgileLendingDirectorBO agileLendingDirectorBO;
    public AgileLendinfOfferDetails agileLendinfOfferDetails;
    public AgileLendingGlobalApprovalDetails agileLendingGlobalApprovalDetails;
    public AgileLendingReferences agileLendingReferences;
    public GetMultipleCustomer getMultipleCustomer;
    public GetBillingAccountBranchDetails getBillingAccountBranchDetails;
    public Metadata @metadata;
}
