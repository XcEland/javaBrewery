public class OccupationStatus{
    public String value;
    public Metadata @metadata;
}
