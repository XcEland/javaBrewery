public class Conditions{
    public ArrayList<Object> selected;
    public ArrayList<Object> items;
    public Metadata @metadata;
}
