public class ArbitrationRqRs{
    public ProcessContext processContext;
    public ReferralDetails referralDetails;
    public DocumentDetails documentDetails;
    public int arbitrationCount;
    public boolean ifFirstArbitrationForOffer;
    public String productId;
    public MotivationDetails motivationDetails;
    public Metadata @metadata;
}
