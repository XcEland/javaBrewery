public class MaritalStatus{
    public String value;
    public Metadata @metadata;
}
