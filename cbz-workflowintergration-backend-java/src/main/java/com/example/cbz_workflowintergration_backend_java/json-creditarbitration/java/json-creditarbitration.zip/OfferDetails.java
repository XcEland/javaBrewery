public class OfferDetails{
    public ArrayList<int> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
}
