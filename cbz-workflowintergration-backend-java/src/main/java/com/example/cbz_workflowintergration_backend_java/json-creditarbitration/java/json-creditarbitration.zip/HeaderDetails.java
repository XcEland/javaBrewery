public class HeaderDetails{
    public String custFirstName;
    public String custSurname;
    public String custIdNumber;
    public String bpId;
    public String acntNo;
    public String offerId;
    public String acntExecutive;
    public MarketSegment marketSegment;
    public Metadata @metadata;
}
