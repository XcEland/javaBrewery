public class Address{
    public String addressLine1;
    public String suburb;
    public String city;
    public String postalCode;
    public AccommodationType accommodationType;
    public String province;
    public String country;
    public Metadata @metadata;
}
