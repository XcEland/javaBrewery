public class DocumentDetails{
    public String fileName;
    public String documentType;
    public String documentID;
    public String contentURL;
    public String createdDate;
    public String uploadedBy;
    public boolean isBranchUploaded;
    public boolean kycIndicator;
    public String kycVerificationDate;
    public String kycVerifiedBy;
    public String docucmentTypeDescription;
    public Metadata @metadata;
}
