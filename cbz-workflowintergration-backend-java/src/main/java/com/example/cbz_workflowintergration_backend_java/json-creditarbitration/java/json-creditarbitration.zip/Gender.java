public class Gender{
    public String value;
    public Metadata @metadata;
}
