public class TempLimit{
    public String limitIndicator;
    public String reviewStartDate;
    public String reviewEndDate;
    public Metadata @metadata;
}
