public class AccountExecutiveDetails{
    public String name;
    public String email;
    public Metadata @metadata;
}
