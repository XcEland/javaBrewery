public class Root{
    public CreditAssessmentDetails creditAssessmentDetails;
    public LdapRqUserAttributes ldapRqUserAttributes;
    public String originatingOfficerId;
    public MotivationDetails motivationDetails;
    public LdapRsUserAttributes ldapRsUserAttributes;
    public String branchOfficerId;
    public String creditEvaluationUser;
    public Object employmentStartDate;
    public String msgGroupReference;
    public LdapUser ldapUser;
    public UsersSearchCriteria usersSearchCriteria;
    public Object employmentEndDate;
    public ArbitrationRqRs arbitrationRqRs;
    public String flowAction;
    public int arbitrationCounter;
    public CustomerDetails customerDetails;
}
