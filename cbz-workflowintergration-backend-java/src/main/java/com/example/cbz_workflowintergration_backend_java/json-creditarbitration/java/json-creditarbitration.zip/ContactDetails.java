public class ContactDetails{
    public String cellPhoneNumber;
    public PreferredContactType preferredContactType;
    public Metadata @metadata;
}
