public class LdapRsUserAttributes{
    @JsonProperty("Buti.Komana@standardbank.co.za") 
    public ButiKomanaStandardbankCoZa buti.Komana@standardbank.co.za;
}
