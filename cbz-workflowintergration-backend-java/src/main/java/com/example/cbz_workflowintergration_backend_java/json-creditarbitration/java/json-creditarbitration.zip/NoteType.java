public class NoteType{
    public Metadata @metadata;
}
