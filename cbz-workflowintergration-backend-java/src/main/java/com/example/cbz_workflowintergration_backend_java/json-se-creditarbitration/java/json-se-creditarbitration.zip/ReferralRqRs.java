public class ReferralRqRs{
    public ProcessContext processContext;
    public ReferralDetails referralDetails;
    public ArbitrationDetails arbitrationDetails;
    public Metadata @metadata;
}
