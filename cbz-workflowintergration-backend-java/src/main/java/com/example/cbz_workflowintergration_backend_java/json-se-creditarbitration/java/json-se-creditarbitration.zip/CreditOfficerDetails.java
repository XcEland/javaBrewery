public class CreditOfficerDetails{
    public String personnelNumber;
    public String emailAddress;
    public String officerType;
    public Metadata @metadata;
}
