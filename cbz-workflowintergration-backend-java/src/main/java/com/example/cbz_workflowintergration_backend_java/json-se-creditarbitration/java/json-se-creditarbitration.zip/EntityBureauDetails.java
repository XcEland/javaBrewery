public class EntityBureauDetails{
    public Metadata @metadata;
}
