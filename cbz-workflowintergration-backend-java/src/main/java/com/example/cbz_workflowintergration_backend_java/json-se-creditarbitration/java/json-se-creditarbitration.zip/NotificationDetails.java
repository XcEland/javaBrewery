public class NotificationDetails{
    public String emailSubject;
    public String emailBody;
    public boolean generateEmailBody;
    public String emailType;
    public Metadata @metadata;
}
