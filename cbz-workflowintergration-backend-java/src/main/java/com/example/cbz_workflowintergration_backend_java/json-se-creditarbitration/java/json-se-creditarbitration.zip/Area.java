public class Area{
    public String name;
    public String value;
    public Metadata @metadata;
}
