public class OuBpId{
    public String name;
    public String value;
    public Metadata @metadata;
}
