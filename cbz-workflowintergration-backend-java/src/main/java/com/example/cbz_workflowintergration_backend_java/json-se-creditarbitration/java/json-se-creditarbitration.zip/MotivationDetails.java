public class MotivationDetails{
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
    public MotivationReasons motivationReasons;
    public String motivationComment;
    public String userId;
    public MotivationDocuments motivationDocuments;
    public Object motivationDate;
}
