public class NotifyCreditOfficerRes{
    public Metadata @metadata;
}
