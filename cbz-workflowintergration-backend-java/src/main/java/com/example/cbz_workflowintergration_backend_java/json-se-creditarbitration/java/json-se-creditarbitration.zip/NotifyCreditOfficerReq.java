public class NotifyCreditOfficerReq{
    public CreditOfficerDetails creditOfficerDetails;
    public NotificationDetails notificationDetails;
    public ApplicationDetails applicationDetails;
    public HeaderDetails headerDetails;
    public Metadata @metadata;
}
