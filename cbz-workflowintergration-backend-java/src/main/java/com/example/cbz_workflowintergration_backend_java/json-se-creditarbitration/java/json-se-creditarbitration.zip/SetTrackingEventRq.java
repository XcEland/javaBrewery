public class SetTrackingEventRq{
    public String channel_ID;
    public String processName;
    public String instanceID;
    public String offerID;
    public String taskName;
    public String assignedDate;
    public String startUserID;
    public String actionedPerformed;
    public Metadata @metadata;
}
