public class BranchDetails{
    public String officerId;
    public String officerName;
    public Branch branch;
    public Center center;
    public Province province;
    public Region region;
    public AccountExecutiveCenter accountExecutiveCenter;
    public Metadata @metadata;
}
