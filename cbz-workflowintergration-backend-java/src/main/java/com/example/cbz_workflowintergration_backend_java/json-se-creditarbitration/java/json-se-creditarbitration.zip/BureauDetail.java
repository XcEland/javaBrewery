public class BureauDetail{
    public EntityBureauDetails entityBureauDetails;
    public JudgementDetails judgementDetails;
    public RelatedPartiesBureauDetails relatedPartiesBureauDetails;
    public Metadata @metadata;
}
