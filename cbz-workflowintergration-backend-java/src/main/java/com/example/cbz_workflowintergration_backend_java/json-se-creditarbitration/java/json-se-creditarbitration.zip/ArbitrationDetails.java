public class ArbitrationDetails{
    public MotivationDetails motivationDetails;
    public int arbitrationCount;
    public boolean ifFirstArbitrationForOffer;
    public String productId;
    public Metadata @metadata;
}
