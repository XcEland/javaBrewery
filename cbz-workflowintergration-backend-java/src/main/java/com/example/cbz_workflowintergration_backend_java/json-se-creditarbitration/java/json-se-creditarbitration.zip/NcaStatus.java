public class NcaStatus{
    public String name;
    public String value;
    public Metadata @metadata;
}
