public class CreditAssessmentDetails{
    public HeaderDetails headerDetails;
    public ApplicationDetails applicationDetails;
    public BranchDetails branchDetails;
    public Notes notes;
    public String rafUniqueKey;
    public Channel channel;
    public String priority;
    public double totCustomerExposure;
    public Documents documents;
    public OuBpId ouBpId;
    public RoutingDetails routingDetails;
    public MotivationDetails motivationDetails;
    public Metadata @metadata;
}
