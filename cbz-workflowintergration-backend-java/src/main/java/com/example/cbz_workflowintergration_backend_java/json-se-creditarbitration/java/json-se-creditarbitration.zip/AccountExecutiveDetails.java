public class AccountExecutiveDetails{
    public String name;
    public Metadata @metadata;
}
