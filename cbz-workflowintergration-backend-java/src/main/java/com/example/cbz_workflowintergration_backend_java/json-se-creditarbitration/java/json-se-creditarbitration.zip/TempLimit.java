public class TempLimit{
    public String limitIndicator;
    public Object limitStartDate;
    public Object limitEndDate;
    public Metadata @metadata;
}
