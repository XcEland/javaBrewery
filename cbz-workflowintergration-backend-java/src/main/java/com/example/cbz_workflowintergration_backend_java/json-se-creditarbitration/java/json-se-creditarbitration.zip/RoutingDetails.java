public class RoutingDetails{
    public int level;
    public double exposure;
    public String previousUser;
    public Province province;
    public Region region;
    public Area area;
    public String collateralCentre;
    public MarketSegment marketSegment;
    public String bpmTeam;
    public PreviousUserList previousUserList;
    public Metadata @metadata;
}
