public class Customer{
    public String firstName;
    public String surname;
    public String id_passportNumber;
    public IdType idType;
    public String initials;
    public String pep_Status;
    public Metadata @metadata;
}
