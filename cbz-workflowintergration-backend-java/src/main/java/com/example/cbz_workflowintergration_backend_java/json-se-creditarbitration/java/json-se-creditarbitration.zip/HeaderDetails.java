public class HeaderDetails{
    public Customer customer;
    public Entity entity;
    public String bpdid;
    public String applicationNumber;
    public String marketSegment;
    public String accountExecutive;
    public String customerType;
    public String accountNumber;
    public String debtReview;
    public String kycStatus;
    public Metadata @metadata;
    public String bpGuid;
}
