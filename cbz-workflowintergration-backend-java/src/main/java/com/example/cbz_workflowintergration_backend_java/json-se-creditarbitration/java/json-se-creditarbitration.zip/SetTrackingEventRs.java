public class SetTrackingEventRs{
    public String status;
    public int eventID;
    public Metadata @metadata;
}
