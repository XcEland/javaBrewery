public class NCAStatus2{
    public String name;
    public String value;
    public Metadata @metadata;
}
