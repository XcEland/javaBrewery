public class CatchmentRoutingDetails{
    public String rmEmailAddress;
    public String preferredCentre;
    public String originatingCentre;
    public boolean staffIndicator;
    public String bpmTeam;
    public String cemEmailAddress;
    public Metadata @metadata;
}
