public class Entity{
    public String entityName;
    public String registrationNumber;
    public String ibtNumber;
    public String businessType;
    public Metadata @metadata;
}
