public class Decision{
    public ArrayList<Object> selected;
    public ArrayList<Item> items;
    public Metadata @metadata;
    public String name;
    public String value;
}
