public class ReferralDetails{
    public String type;
    public String offerId;
    public Date appDate;
    public BranchDetails branchDetails;
    public MarketSegment marketSegment;
    public String rafUniqueKey;
    public boolean fraudReferral;
    public boolean creditReferral;
    public double exposure;
    public OuBpId ouBpId;
    public String lastActionUser;
    public Metadata @metadata;
}
