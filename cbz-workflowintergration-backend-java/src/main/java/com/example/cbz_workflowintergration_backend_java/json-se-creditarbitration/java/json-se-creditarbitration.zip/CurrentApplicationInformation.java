public class CurrentApplicationInformation{
    public double currentBalance;
    public double currentLimit;
    public double currentInstallment;
    public double currentInterestRate;
    public int currentLoanTerm;
    public Metadata @metadata;
}
