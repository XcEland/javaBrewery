public class OtherApplicationDetails{
    public Attribute attribute;
    public Metadata @metadata;
}
