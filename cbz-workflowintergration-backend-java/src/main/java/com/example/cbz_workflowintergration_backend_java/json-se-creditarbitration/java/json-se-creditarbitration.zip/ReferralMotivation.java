public class ReferralMotivation{
    public ArrayList<Object> selected;
    public ArrayList<String> items;
    public Metadata @metadata;
}
