package com.example.cbz_workflowintergration_backend_java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CbzWorkflowintergrationBackendJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
